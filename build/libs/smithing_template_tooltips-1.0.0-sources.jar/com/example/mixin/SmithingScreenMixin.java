package com.example.mixin;

import com.example.ExampleMod;
import net.minecraft.class_332;
import net.minecraft.class_4895;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4895.class)
public class SmithingScreenMixin {
    /**
     * Inject into the render method with the correct signature
     * Note that DrawContext is the first parameter, followed by mouseX (I), mouseY (I), and delta (F)
     */
    @Inject(method = "render", at = @At("RETURN"))
    private void render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            // Your render enhancement logic goes here
            ExampleMod.LOGGER.debug("SmithingScreen render mixin injection successful");
        } catch (Exception e) {
            ExampleMod.LOGGER.error("Error in SmithingScreen render mixin", e);
        }
    }
}
